// netlify/functions/meta.js
// Proxies Meta Ads API requests — token stays on the server, never in the browser.

const META_TOKEN = process.env.META_TOKEN;   // set in Netlify dashboard → Environment variables
const META_ACCT  = process.env.META_ACCT;    // e.g. act_123456789

const CORS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const FIELDS = [
  "campaign_name", "adset_name", "ad_name", "objective",
  "spend", "impressions", "reach", "clicks", "ctr", "frequency",
  "actions", "cost_per_action_type",
].join(",");

exports.handler = async (event) => {
  // Preflight
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }

  if (!META_TOKEN || !META_ACCT) {
    return {
      statusCode: 500,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "META_TOKEN y META_ACCT no configurados en Netlify → Environment Variables" }),
    };
  }

  const { since, until } = event.queryStringParameters || {};
  if (!since || !until) {
    return {
      statusCode: 400,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Faltan parámetros: since, until" }),
    };
  }

  const params = new URLSearchParams({
    fields:     FIELDS,
    time_range: JSON.stringify({ since, until }),
    level:      "ad",
    limit:      "500",
    access_token: META_TOKEN,
  });

  const url = `https://graph.facebook.com/v19.0/${META_ACCT}/insights?${params}`;

  try {
    const res  = await fetch(url);
    const data = await res.json();

    if (data.error) {
      return {
        statusCode: 400,
        headers: { ...CORS, "Content-Type": "application/json" },
        body: JSON.stringify({ error: data.error.message }),
      };
    }

    return {
      statusCode: 200,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ data: data.data || [], paging: data.paging }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message }),
    };
  }
};
